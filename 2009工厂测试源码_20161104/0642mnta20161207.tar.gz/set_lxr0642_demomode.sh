#config this handheld to LXR0642 user mode:
#upon starting, it runs the LXR0642 user program:

cd userapp

#add LXR0642 key_monitor program:
mv icon_km.bak icon_km

#set userprogram to LXR0642 user demo program:
ln -sf lxr0642_barcode_sleep_demo.x user_mainprogram.ln

