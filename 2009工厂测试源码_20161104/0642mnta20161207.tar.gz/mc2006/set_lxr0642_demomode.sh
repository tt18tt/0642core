#config this handheld to LXR0642 user mode:
#upon starting, it runs the LXR0642 user program:

#set default user password for following boot:
cd /mnt/a
mv user-info.tar.gz user-info.tar.gz.bak

#set correct .launcher
cd /mnt/a/etc
ln -sf .launcher_lxr0642 .launcher
#delete config of gprs/cdma:
rm mc2006CFG

#set userprogram to LXR0642 user demo program:
cd /mnt/a/userapp
ln -sf lxr0642_barcode_sleep_demo.x user_mainprogram.ln

