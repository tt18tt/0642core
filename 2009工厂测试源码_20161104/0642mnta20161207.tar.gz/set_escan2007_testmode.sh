#config this handheld to ESCAN2007 test mode:
#upon starting, it runs the ESCAN2007 test program:

cd userapp

#remove LXR0642 key_monitor program:
mv icon_km icon_km.bak

#set userprogram to testprog:
ln -sf mb_lyff_yxl_testprog_suspend.x user_mainprogram.ln

