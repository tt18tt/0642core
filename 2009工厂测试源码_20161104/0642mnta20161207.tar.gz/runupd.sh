cd /mnt/a

#killall launcher
tar -xzf mnta*.tz

#update NDA:
mc2006_nw NDA NDA.bin

echo 
echo "please reboot the handheld."

