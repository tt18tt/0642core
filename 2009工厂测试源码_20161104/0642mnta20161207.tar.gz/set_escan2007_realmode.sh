#config this handheld to ESCAN2007 real use mode:
#upon starting, it runs the ESCAN2007 user program:

cd userapp

#remove LXR0642 key_monitor program:
mv icon_km icon_km.bak

#set userprogram to user app prog:
ln -sf mb_lyff_yxl.x user_mainprogram.ln

