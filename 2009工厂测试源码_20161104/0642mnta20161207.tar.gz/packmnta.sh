tar -cvzf 0642mnta$1.tar.gz  bin/ mc2006/ userapp/  .profile *.sh etc/


